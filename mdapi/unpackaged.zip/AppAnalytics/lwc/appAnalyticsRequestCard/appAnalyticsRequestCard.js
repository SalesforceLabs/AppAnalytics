import { LightningElement, api } from 'lwc';

export default class AppAnalyticsRequestCard extends LightningElement {
  @api request;
}